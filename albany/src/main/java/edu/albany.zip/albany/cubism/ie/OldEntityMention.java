/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.albany.cubism.ie;

import adept.common.TokenOffset;
import adept.common.TokenStream;

/**
 *
 * @author ting
 */
public class OldEntityMention extends adept.common.EntityMention {

    public OldEntityMention(long sequenceId, TokenOffset tokenOffset, TokenStream tokenStream) {
        super(sequenceId, tokenOffset, tokenStream);
    }
    
}
