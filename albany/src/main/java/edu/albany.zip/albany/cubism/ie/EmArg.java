/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.albany.cubism.ie;

/**
 *
 * @author Mehrdad
 */
public class EmArg {
    private String id;
    private String entity_mention_id;
    private String role;
    private String realis;
    private String em_arg;
}
