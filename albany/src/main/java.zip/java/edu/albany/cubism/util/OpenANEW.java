/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.albany.cubism.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import edu.albany.cubism.util.Settings;

/**
 *
 * @author jrgiarrusso
 */
public class OpenANEW {

    private final String dataurl = "jdbc:mysql://cycles.ss.albany.edu/metaphor_repository?useUnicode=true&characterEncoding=utf-8";
    private final String user = "anassman";
    private final String password = "D0samrD9";
    private Connection con;
    HashMap<String, Double> wsMap=new HashMap<String, Double>();
    HashMap<String, Double> twitterMap = new HashMap<String, Double>();
    private ArrayList<String> non_sent_heads = new ArrayList<String>() {
        {
            add("time_unit");
        }
    };

    public OpenANEW(){
            BufferedReader br=null;
        try {
            String aNewPath = Settings.getValue("ANEW");
            System.out.println("aNew path: " + aNewPath);
            br = new BufferedReader(new FileReader(new File(aNewPath)));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(OpenANEW.class.getName()).log(Level.SEVERE, null, ex);
        }

            String a_line = null;
            int i=0;
            try {
                while((a_line = br.readLine()) != null) {
                    if (i==0){
                        i++;
                        continue;
                    }
                    
                    i++;
                    if (a_line.trim().length() > 0) {
                        String[] tokens=a_line.split("\t");
                        String word=tokens[4].trim();
                        double score= Double.parseDouble(tokens[1]);
                        wsMap.put(word, score);
                    }
                }
                br.close();
//                System.out.println("bad_relations: " + bad_relations);
            } catch (IOException ex) {
                System.out.println("No anew_english_hyponym_sept2013.csv");
            }
            this.loadTwitterSentiWords();
    }
    public void loadTwitterSentiWords() {
        BufferedReader br = null;
        String twitterPath = Settings.getValue(Settings.twitters_sentiment_words);
        try {
            br = new BufferedReader(new FileReader(new File(twitterPath)));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(OpenANEW.class.getName()).log(Level.SEVERE, null, ex);
        }
            String a_line = null;
            int i=0;
            try {
                while((a_line = br.readLine()) != null) {
                    if (i==0){
                        i++;
                        continue;
                    }
                    
                    i++;
                    if (a_line.trim().length() > 0) {
                        String[] tokens=a_line.split(": ");
                        String word=tokens[0].trim();
                        double score= Double.parseDouble(tokens[1].trim());
                        this.twitterMap.put(word, score);
                    }
                }
                br.close();
//                System.out.println("bad_relations: " + bad_relations);
            } catch (IOException ex) {
                System.out.println("No anew_english_hyponym_sept2013.csv");
            }
    }
    public Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(dataurl, user, password);
        } catch (Exception ex) {
            Logger.getLogger(OpenANEW.class.getName()).log(Level.SEVERE, null, ex);
            System.out.flush();
            System.err.println("Error connecting to database");
            System.exit(1);
        }
        return con;
    }

    public void printTable() {
        if (con == null) {
            con = this.getConnection();
        }
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = con.prepareStatement("SELECT * FROM DEFT.anew_english_hyponym_sept2013 where id > ?");
            ps.setInt(1, 95555);
            rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getInt("id") + "\t" + rs.getDouble("score") + "\t" + rs.getString("english_derived") + "\t" + rs.getString("word"));
            }

            rs.close();
            ps.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(1);
            System.out.flush();
            System.err.println("Error executing query");
        }

    }

    public double wordSentimentOf(String word) {

//        double wordScore = -1;
//        if (con == null) {
//            con = this.getConnection();
//        }
//        PreparedStatement ps;
//        ResultSet rs;
//        try {
//            ps = con.prepareStatement("SELECT score FROM DEFT.anew_english_hyponym_sept2013 where word = ?");
//            ps.setString(1, word);
//            rs = ps.executeQuery();
//            while (rs.next()) {
////                System.out.println(rs.getDouble("score"));
//                wordScore = rs.getDouble("score");
//            }
//
//            rs.close();
//            ps.close();
//        } catch (Exception ex) {
//            ex.printStackTrace();
//            System.exit(1);
//            System.out.flush();
//            System.err.println("Error executing query");
//        }
//
//        return wordScore;
        
        double wordScore = -1;
        
        if (wsMap.containsKey(word))
            return wsMap.get(word);
        if (this.twitterMap.containsKey(word)) {
            System.out.println("find a sentiment from twitter sentiment map: " + word);
            return this.twitterMap.get(word);
        }
        return wordScore;

    }

    public static void main(String... args) throws SQLException, IOException {
//         new OpenANEW().printTable();
        OpenANEW oa = new OpenANEW();
        System.out.println("word senti: " + oa.wordSentimentOf("impressed"));
        System.out.println("word senti: " + oa.wordSentimentOf("asshat"));
      }
}
